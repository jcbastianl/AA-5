public class Carrer {
    public String name;
    private Alumno[] alumnoList;


}