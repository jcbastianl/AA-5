public class Director extends Professor{
    public void enseniar(){
        System.out.println("Como pueda...");
    }
}
