public class Brazo {
    private Persona persona;
}
