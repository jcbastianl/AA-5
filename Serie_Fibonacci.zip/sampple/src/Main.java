﻿public class Main {
    public static void main(String[] args) {
        Persona persona;
        persona = new Persona();
        persona.respire();

        Alumno alumno = new Alumno();
        alumno.respire();

        new Professor().recorderDistance(new Distance(25));

        Distance d;
        d = new Distance();
        d.verLongitud();
        Distance d2 = new Distance(7);
        d2.verLongitud();
        persona.recorderDistance(d);
        alumno.recorderDistance(d2);
        alumno.recorderDistance(new Distance(10));


        Professor p1 = new Professor();
        p1.enseniar();
        Director dir = new Director();
        dir.enseniar();
    }
}