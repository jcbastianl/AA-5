public class Signature {
    public String name;
    private Alumno estudiante;
}
