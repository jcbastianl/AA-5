public interface Contrato {
    public void enseniar();

}
