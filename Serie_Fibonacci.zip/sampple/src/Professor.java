public class Professor extends Persona implements Contrato{
    private final String speciality = "Software";

    public void teach(){
        System.out.println("Teaching...");
    }

    @Override
    public void enseniar(){
        System.out.println("Enseñando...");
    }
}
