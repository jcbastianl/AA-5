public class Distance {
    private int longitud;
    private final String unit = "metros";

    public Distance(){
        longitud = 5;
    }

    public Distance(int longitud){
        this.longitud = longitud;
        this.verLongitud();
    }

    public void verLongitud(){
        System.out.println(longitud + " " + unit);
    }
}
