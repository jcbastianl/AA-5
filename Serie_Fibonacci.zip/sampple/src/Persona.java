public class Persona {
    private String name;
    protected String secondName;
    private Ropa[] ropaList;
    private final Brazo[] brazoList;

    public Persona(){
        this.brazoList = new Brazo[2];
    }

    public void respire(){
        System.out.println("Respiro...");
    }

    public void recorderDistance(Distance d){
        System.out.println("Se recorrio:");
        d.verLongitud();
    }




}
