public class Ropa {

    private Persona[] personaList;
}
