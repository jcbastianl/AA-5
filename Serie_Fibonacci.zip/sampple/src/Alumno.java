public class Alumno extends Persona{
    private Signature asignatura;
}
